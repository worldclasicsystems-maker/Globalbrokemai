import threading, time
from gbai.scheduler import Scheduler, TaskStatus
from gbai.module_health import ModuleHealthManager, HealthState

def test_scheduler_runs_task():
    s=Scheduler(lambda name,payload: payload["x"]*2, max_workers=1)
    t=s.submit("double",{"x":4})
    deadline=time.time()+2
    while t.status in (TaskStatus.QUEUED,TaskStatus.RUNNING) and time.time()<deadline: time.sleep(.01)
    assert t.status==TaskStatus.SUCCEEDED and t.result==8
    s.shutdown()

def test_priority_queue_and_capacity():
    gate=threading.Event()
    started=[]
    def run(name,payload):
        started.append(payload["id"])
        gate.wait(1)
        return payload["id"]
    s=Scheduler(run,max_workers=1,max_queue=3)
    first=s.submit("m",{"id":"first"})
    time.sleep(.05)
    low=s.submit("m",{"id":"low"},priority=0)
    high=s.submit("m",{"id":"high"},priority=9)
    gate.set()
    deadline=time.time()+2
    while high.status not in (TaskStatus.SUCCEEDED,TaskStatus.FAILED) and time.time()<deadline: time.sleep(.01)
    assert started[0]=="first" and started[1]=="high"
    s.shutdown()

def test_cancel_queued_task():
    gate=threading.Event()
    s=Scheduler(lambda n,p: (gate.wait(.5),p)[1],max_workers=1)
    a=s.submit("m",{"id":1}); time.sleep(.03)
    b=s.submit("m",{"id":2})
    assert s.cancel(b.task_id)
    assert b.status==TaskStatus.CANCELLED
    gate.set(); s.shutdown()

def test_health_quarantine_and_reset():
    h=ModuleHealthManager(failure_threshold=2)
    h.failure("mod","bad"); assert h.get("mod").state==HealthState.DEGRADED
    h.failure("mod","bad again"); assert not h.is_allowed("mod")
    h.reset("mod"); assert h.is_allowed("mod")
