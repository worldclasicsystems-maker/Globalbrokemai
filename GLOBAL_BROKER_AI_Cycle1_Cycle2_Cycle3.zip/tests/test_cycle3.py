import json
from gbai.config import Settings
from gbai.database import JobStore
from gbai.service import CoreService
from gbai.builtin import EchoModule

def make_settings(p): return Settings(data_dir=str(p),database_path=str(p/'jobs.db'),audit_path=str(p/'audit.db'))
def test_store(tmp_path):
 s=JobStore(tmp_path/'jobs.db'); j=s.create('echo',{'x':1}); assert j['status']=='queued'; assert json.loads(j['payload_json'])=={'x':1}
def test_job_flow_and_audit(tmp_path):
 s=CoreService(make_settings(tmp_path)); j=s.submit_job('echo',{'a':2}); r=s.run_job(j['id']); assert r['status']=='succeeded'; assert json.loads(r['result_json'])=={'echo':{'a':2}}; assert s.health()['status']=='ok'; s.close()
def test_unknown_module_no_job(tmp_path):
 s=CoreService(make_settings(tmp_path))
 try:
  try: s.submit_job('missing',{})
  except KeyError: pass
  else: assert False
  assert s.store.list()==[]
 finally: s.close()
def test_run_once(tmp_path):
 s=CoreService(make_settings(tmp_path)); j=s.submit_job('echo',{}); s.run_job(j['id'])
 try: s.run_job(j['id'])
 except ValueError: pass
 else: assert False
 s.close()
