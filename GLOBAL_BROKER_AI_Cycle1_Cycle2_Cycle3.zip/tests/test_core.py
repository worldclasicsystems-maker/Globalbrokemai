from gbai.kernel import Kernel
from gbai.registry import ModuleRegistry
from gbai.proof import ProofEngine
class Add:
    name="add"
    def execute(self,p): return p["a"]+p["b"]
class Fail:
    name="fail"
    def execute(self,p): raise RuntimeError("intentional")
def test_task_and_chain(tmp_path):
    k=Kernel(tmp_path/"audit.db"); k.start(); k.register(Add())
    r=k.execute("add",{"a":2,"b":3}); assert r.success and r.result==5
    assert k.proof.verify()[0]; k.stop()
def test_failure_does_not_stop_kernel(tmp_path):
    k=Kernel(tmp_path/"a.db"); k.start(); k.register(Fail()); assert not k.execute("fail",{}).success
    k.register(Add()); assert k.execute("add",{"a":1,"b":4}).result==5
    assert k.proof.verify()[0]; k.stop()
def test_duplicate_registration():
    r=ModuleRegistry(); r.register(Add())
    try: r.register(Add()); assert False
    except ValueError: pass
def test_detects_tampering(tmp_path):
    p=ProofEngine(tmp_path/"p.db"); p.append("event",{"x":1}); assert p.verify()[0]
    p.db.execute("UPDATE audit SET payload='{}' WHERE seq=1"); p.db.commit()
    assert not p.verify()[0]; p.close()
def test_reopen_chain(tmp_path):
    path=tmp_path/"persist.db"; p=ProofEngine(path); p.append("one",{}); p.close()
    p=ProofEngine(path); p.append("two",{}); assert p.verify()[0]; p.close()
