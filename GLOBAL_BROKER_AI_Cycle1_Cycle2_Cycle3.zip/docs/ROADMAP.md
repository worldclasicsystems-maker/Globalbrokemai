# Staged roadmap
1. Cycle 1: kernel, registry, task execution, local audit, tests and CI.
2. Cycle 2: task queue, priorities, cancellation, bounded execution, module health.
3. Cycle 3: typed contracts, independent validators, replay and failure taxonomy.
4. Cycle 4: local data adapters, provenance, schemas and deduplication.
5. Cycle 5: agents with permission boundaries, budgets and human approval.
6. Cycle 6: measured optimization, observability and optional integrations.
Core must remain local-first; paid APIs are never a requirement.
