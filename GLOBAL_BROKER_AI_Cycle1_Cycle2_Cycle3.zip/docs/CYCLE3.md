# Cycle 3 — persistent control plane

Added environment configuration, SQLite job persistence, a service layer, a small standard-library HTTP control API, explicit job lifecycle handling and POST /jobs/{id}/run execution route, an example echo module and tests.

Security: loopback bind by default; remote bind requires both `GBAI_ALLOW_REMOTE=true` and `GBAI_API_TOKEN`; bearer token comparison is constant-time; HTTP request body is capped at 1 MB; no generic code execution endpoint.

Limitations: local development control plane only; single bearer token; no TLS termination, RBAC or rate limiting; job run is synchronous and invoked explicitly; SQLite is single-node. Hash-chain audit is tamper-evident for record alteration but not a signature or external immutable ledger.
