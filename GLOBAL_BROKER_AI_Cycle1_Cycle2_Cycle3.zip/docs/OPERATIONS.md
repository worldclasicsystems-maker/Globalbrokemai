# Operations

Install Python 3.11+ and run `python -m pip install -e .`. Set `GBAI_DATA_DIR`, `GBAI_DATABASE_PATH`, `GBAI_AUDIT_PATH` for persistence. Keep `GBAI_HOST=127.0.0.1` for local use. Remote binding requires a long random `GBAI_API_TOKEN` and `GBAI_ALLOW_REMOTE=true`, plus TLS, firewall and reverse proxy in deployment. Register only reviewed modules: their `execute()` runs with the process permissions. Never commit tokens. Run `pytest` before release.
