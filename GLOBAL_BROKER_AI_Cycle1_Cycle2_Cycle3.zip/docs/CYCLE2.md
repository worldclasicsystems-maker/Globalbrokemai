# Cycle 2 — Scheduling and isolation

Cycle 2 adds a bounded worker scheduler with priority ordering, task snapshots,
cooperative cancellation, timeout marking, module health tracking and quarantine.

## Important limits
- A Python thread cannot be safely force-killed. Cancellation is cooperative;
  module code can observe the injected `_cancel_event`.
- `expire()` is a deadline check that the host must call periodically. It marks
  a task timed out and signals cancellation; it does not reclaim a blocked
  thread until the module returns.
- Quarantined modules require explicit `reset()` after operator review.
- This is a local in-process scheduler, not a distributed queue.
