from .config import Settings
from .service import CoreService
from .http_api import make_server
def main():
 settings=Settings.from_env(); service=CoreService(settings); server=make_server(service,settings)
 print(f"GBAI local API listening on http://{settings.host}:{settings.port}")
 try: server.serve_forever()
 except KeyboardInterrupt: pass
 finally: server.server_close(); service.close()
if __name__=="__main__": main()
