from pathlib import Path
import sqlite3, json, uuid, datetime
SCHEMA="""CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,module TEXT NOT NULL,payload_json TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('queued','running','succeeded','failed','cancelled')),result_json TEXT,error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL); CREATE INDEX IF NOT EXISTS idx_jobs_status_created ON jobs(status,created_at);"""
class JobStore:
    def __init__(self,path):
        self.path=str(path); Path(self.path).parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db: db.executescript(SCHEMA)
    def connect(self):
        db=sqlite3.connect(self.path,timeout=10); db.row_factory=sqlite3.Row; db.execute('PRAGMA journal_mode=WAL'); db.execute('PRAGMA foreign_keys=ON'); return db
    @staticmethod
    def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
    def create(self,module,payload):
        jid=str(uuid.uuid4()); now=self.now()
        with self.connect() as db: db.execute('INSERT INTO jobs(id,module,payload_json,status,created_at,updated_at) VALUES(?,?,?,?,?,?)',(jid,module,json.dumps(payload,sort_keys=True), 'queued',now,now))
        return self.get(jid)
    def get(self,jid):
        with self.connect() as db: row=db.execute('SELECT * FROM jobs WHERE id=?',(jid,)).fetchone()
        return dict(row) if row else None
    def list(self,limit=50):
        limit=max(1,min(int(limit),200))
        with self.connect() as db: rows=db.execute('SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?',(limit,)).fetchall()
        return [dict(r) for r in rows]
    def transition(self,jid,status,result=None,error=None):
        if status not in {'queued','running','succeeded','failed','cancelled'}: raise ValueError('invalid job status')
        with self.connect() as db:
            cur=db.execute('UPDATE jobs SET status=?,result_json=?,error=?,updated_at=? WHERE id=?',(status,json.dumps(result,sort_keys=True,default=str) if result is not None else None,error,self.now(),jid))
            if cur.rowcount!=1: raise KeyError(jid)
        return self.get(jid)
