from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, Future
from dataclasses import dataclass
from enum import Enum
from threading import Event, Lock
from typing import Any, Callable
import time
import uuid

class TaskStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMED_OUT = "timed_out"

@dataclass
class ScheduledTask:
    task_id: str
    module_name: str
    payload: dict[str, Any]
    priority: int = 0
    timeout_seconds: float = 30.0
    status: TaskStatus = TaskStatus.QUEUED
    result: Any = None
    error: str | None = None
    submitted_at: float = 0.0
    started_at: float | None = None
    finished_at: float | None = None
    cancel_event: Event | None = None

class Scheduler:
    """Bounded worker pool with priority ordering and cooperative cancellation.

    A running Python function cannot safely be forcibly killed. Cancellation of
    running work is cooperative: modules may inspect payload['_cancel_event'].
    Timeout records the timeout and cancels queued work; it does not claim to
    terminate an arbitrary blocked native call.
    """
    def __init__(self, executor: Callable[[str, dict], Any], max_workers=2,
                 max_queue=100, proof=None):
        if max_workers < 1 or max_queue < 1:
            raise ValueError("max_workers and max_queue must be positive")
        self.executor = executor
        self.max_workers = max_workers
        self.max_queue = max_queue
        self.proof = proof
        self._pool = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="gbai")
        self._lock = Lock()
        self._tasks: dict[str, ScheduledTask] = {}
        self._pending: list[ScheduledTask] = []
        self._futures: dict[str, Future] = {}
        self._closed = False
        self._active = 0

    def submit(self, module_name: str, payload: dict, priority=0,
               timeout_seconds=30.0) -> ScheduledTask:
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        with self._lock:
            if self._closed: raise RuntimeError("scheduler is closed")
            if len(self._pending) >= self.max_queue:
                raise RuntimeError("scheduler queue is full")
            task = ScheduledTask(uuid.uuid4().hex, module_name, dict(payload),
                                 int(priority), float(timeout_seconds),
                                 submitted_at=time.monotonic(), cancel_event=Event())
            self._tasks[task.task_id] = task
            self._pending.append(task)
            self._pending.sort(key=lambda t: (-t.priority, t.submitted_at))
            self._dispatch_locked()
            self._record("task.queued", {"task_id":task.task_id,"module":module_name,
                                         "priority":task.priority})
            return task

    def _dispatch_locked(self):
        while not self._closed and self._active < self.max_workers and self._pending:
            task = self._pending.pop(0)
            if task.status == TaskStatus.CANCELLED: continue
            self._active += 1
            task.status = TaskStatus.RUNNING
            task.started_at = time.monotonic()
            future = self._pool.submit(self._run, task)
            self._futures[task.task_id] = future

    def _run(self, task):
        self._record("task.started", {"task_id":task.task_id,"module":task.module_name})
        payload = dict(task.payload)
        payload["_cancel_event"] = task.cancel_event
        try:
            # The worker may finish after timeout; don't overwrite a terminal status.
            result = self.executor(task.module_name, payload)
            with self._lock:
                if task.status == TaskStatus.RUNNING:
                    task.result = result
                    task.status = TaskStatus.SUCCEEDED
                    self._record("task.completed", {"task_id":task.task_id})
        except Exception as exc:
            with self._lock:
                if task.status == TaskStatus.RUNNING:
                    task.error = f"{type(exc).__name__}: {exc}"
                    task.status = TaskStatus.FAILED
                    self._record("task.failed", {"task_id":task.task_id,"error":task.error})
        finally:
            with self._lock:
                task.finished_at = time.monotonic()
                self._active -= 1
                self._futures.pop(task.task_id, None)
                self._dispatch_locked()

    def cancel(self, task_id: str) -> bool:
        with self._lock:
            task = self._tasks.get(task_id)
            if task is None or task.status in (TaskStatus.SUCCEEDED, TaskStatus.FAILED,
                    TaskStatus.CANCELLED, TaskStatus.TIMED_OUT):
                return False
            if task.cancel_event: task.cancel_event.set()
            if task.status == TaskStatus.QUEUED:
                task.status = TaskStatus.CANCELLED
                task.finished_at = time.monotonic()
                self._pending = [t for t in self._pending if t.task_id != task_id]
            else:
                # Cooperative signal; worker remains occupied until it returns.
                task.status = TaskStatus.CANCELLED
                task.finished_at = time.monotonic()
            self._record("task.cancelled", {"task_id":task_id})
            self._dispatch_locked()
            return True

    def expire(self, now=None) -> list[str]:
        """Mark tasks past their deadline; caller may invoke periodically."""
        now = time.monotonic() if now is None else now
        expired = []
        with self._lock:
            for task in self._tasks.values():
                if task.status == TaskStatus.RUNNING and task.started_at is not None:
                    if now - task.started_at >= task.timeout_seconds:
                        task.status = TaskStatus.TIMED_OUT
                        task.finished_at = now
                        if task.cancel_event: task.cancel_event.set()
                        expired.append(task.task_id)
                        self._record("task.timed_out", {"task_id":task.task_id})
        return expired

    def get(self, task_id: str) -> ScheduledTask | None:
        with self._lock: return self._tasks.get(task_id)

    def snapshot(self) -> tuple[ScheduledTask, ...]:
        with self._lock: return tuple(self._tasks.values())

    def _record(self, event, payload):
        if self.proof is not None: self.proof.append(event, payload)

    def shutdown(self, wait=True):
        with self._lock:
            if self._closed: return
            self._closed = True
            for task in self._pending:
                task.status = TaskStatus.CANCELLED
                if task.cancel_event: task.cancel_event.set()
            self._pending.clear()
            for task in self._tasks.values():
                if task.status == TaskStatus.RUNNING and task.cancel_event:
                    task.cancel_event.set()
        self._pool.shutdown(wait=wait, cancel_futures=True)
