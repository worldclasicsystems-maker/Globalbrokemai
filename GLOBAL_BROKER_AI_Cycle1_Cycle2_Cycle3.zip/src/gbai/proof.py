import hashlib, json, sqlite3
from pathlib import Path
GENESIS = "0" * 64
def canonical(v):
    return json.dumps(v, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
class ProofEngine:
    def __init__(self, path):
        self.db = sqlite3.connect(str(path))
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), event TEXT NOT NULL, payload TEXT NOT NULL, prev_hash TEXT NOT NULL, record_hash TEXT NOT NULL)")
        self.db.commit()
    def append(self, event, payload):
        payload = canonical(payload)
        prev = self.db.execute("SELECT record_hash FROM audit ORDER BY seq DESC LIMIT 1").fetchone()
        prev = prev[0] if prev else GENESIS
        ts = self.db.execute("SELECT strftime('%Y-%m-%dT%H:%M:%fZ','now')").fetchone()[0]
        body = {"timestamp":ts,"event":event,"payload":payload,"prev_hash":prev}
        digest = hashlib.sha256(canonical(body).encode()).hexdigest()
        self.db.execute("INSERT INTO audit(timestamp,event,payload,prev_hash,record_hash) VALUES(?,?,?,?,?)",(ts,event,payload,prev,digest))
        self.db.commit()
        return digest
    def verify(self):
        prev = GENESIS
        rows = self.db.execute("SELECT seq,timestamp,event,payload,prev_hash,record_hash FROM audit ORDER BY seq").fetchall()
        for seq,ts,event,payload,link,digest in rows:
            if link != prev: return False, f"record {seq}: previous hash mismatch"
            body = {"timestamp":ts,"event":event,"payload":payload,"prev_hash":link}
            if hashlib.sha256(canonical(body).encode()).hexdigest() != digest: return False, f"record {seq}: hash mismatch"
            prev = digest
        return True, f"verified {len(rows)} records"
    def close(self): self.db.close()
