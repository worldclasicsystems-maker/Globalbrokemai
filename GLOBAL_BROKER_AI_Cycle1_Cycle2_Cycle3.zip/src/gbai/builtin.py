class EchoModule:
 name='echo'
 def execute(self,payload):
  if not isinstance(payload,dict): raise TypeError('payload must be an object')
  return {'echo':payload}
