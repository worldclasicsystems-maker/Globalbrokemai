from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json,hmac

def make_server(service,settings):
 class Handler(BaseHTTPRequestHandler):
  server_version='GBAI-Core/0.3'
  def reply(self,code,data):
   raw=json.dumps(data,ensure_ascii=False,default=str).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(raw)
  def auth(self):
   if not settings.api_token: return True
   return hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+settings.api_token)
  def do_GET(self):
   if not self.auth(): return self.reply(401,{'error':'unauthorized'})
   if self.path=='/health': return self.reply(200,service.health())
   if self.path=='/ready':
    h=service.health(); return self.reply(200 if h['status']=='ok' else 503,h)
   if self.path=='/modules': return self.reply(200,{'modules':service.modules()})
   if self.path=='/jobs': return self.reply(200,{'jobs':service.store.list()})
   if self.path.startswith('/jobs/'):
    job=service.store.get(self.path.split('/',2)[2]); return self.reply(200,job) if job else self.reply(404,{'error':'not found'})
   return self.reply(404,{'error':'not found'})
  def do_POST(self):
   if not self.auth(): return self.reply(401,{'error':'unauthorized'})
   if self.path.startswith('/jobs/') and self.path.endswith('/run'):
    jid=self.path[len('/jobs/'):-len('/run')]
    try: return self.reply(200,{'job':service.run_job(jid)})
    except KeyError as e: return self.reply(404,{'error':str(e)})
    except ValueError as e: return self.reply(409,{'error':str(e)})
   if self.path!='/jobs': return self.reply(404,{'error':'not found'})
   try:
    n=int(self.headers.get('Content-Length','0'))
    if n<=0 or n>1000000: return self.reply(413,{'error':'invalid body size'})
    body=json.loads(self.rfile.read(n))
    if not isinstance(body,dict) or not isinstance(body.get('module'),str) or not isinstance(body.get('payload',{}),dict): return self.reply(400,{'error':'expected module string and object payload'})
    job=service.submit_job(body['module'],body.get('payload',{})); return self.reply(201,{'job':job,'run_endpoint':f"/jobs/{job['id']}/run"})
   except KeyError as e: return self.reply(404,{'error':str(e)})
   except (ValueError,json.JSONDecodeError) as e: return self.reply(400,{'error':str(e)})
  def log_message(self,fmt,*args): super().log_message(fmt,*args)
 return ThreadingHTTPServer((settings.host,settings.port),Handler)
