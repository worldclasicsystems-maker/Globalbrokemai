from dataclasses import dataclass
from enum import Enum
from .proof import ProofEngine
from .registry import ModuleRegistry
class State(str, Enum):
    CREATED="created"; RUNNING="running"; STOPPED="stopped"
@dataclass(frozen=True)
class TaskResult:
    task_id: str
    success: bool
    result: object = None
    error: str | None = None
class Kernel:
    def __init__(self, audit_path="gbai-audit.sqlite3"):
        self.registry=ModuleRegistry(); self.proof=ProofEngine(audit_path); self.state=State.CREATED; self.counter=1
    def start(self):
        if self.state == State.STOPPED: raise RuntimeError("stopped kernel cannot restart")
        if self.state == State.RUNNING: return
        self.state=State.RUNNING; self.proof.append("kernel.started",{})
    def register(self,module):
        self.registry.register(module); self.proof.append("module.registered",{"name":module.name})
    def execute(self,name,payload):
        if self.state != State.RUNNING: raise RuntimeError("kernel must be running")
        task=f"task-{self.counter:06d}"; self.counter+=1
        self.proof.append("task.started",{"task_id":task,"module":name})
        try:
            result=self.registry.get(name).execute(payload)
            self.proof.append("task.completed",{"task_id":task,"result":result})
            return TaskResult(task,True,result=result)
        except Exception as exc:
            err=f"{type(exc).__name__}: {exc}"
            self.proof.append("task.failed",{"task_id":task,"error":err})
            return TaskResult(task,False,error=err)
    def stop(self):
        if self.state == State.STOPPED: return
        self.proof.append("kernel.stopped",{}); self.state=State.STOPPED; self.proof.close()
