from dataclasses import dataclass
import os

def _bool(name, default):
    value=os.getenv(name)
    if value is None: return default
    value=value.strip().lower()
    if value in {'1','true','yes','on'}: return True
    if value in {'0','false','no','off'}: return False
    raise ValueError(f'{name} must be a boolean')

@dataclass(frozen=True)
class Settings:
    data_dir: str='./data'
    database_path: str='./data/gbai.sqlite3'
    audit_path: str='./data/audit.sqlite3'
    host: str='127.0.0.1'
    port: int=8787
    api_token: str|None=None
    allow_remote: bool=False
    @classmethod
    def from_env(cls):
        port=int(os.getenv('GBAI_PORT','8787'))
        if not 1<=port<=65535: raise ValueError('GBAI_PORT out of range')
        token=os.getenv('GBAI_API_TOKEN') or None
        remote=_bool('GBAI_ALLOW_REMOTE',False)
        host=os.getenv('GBAI_HOST','127.0.0.1')
        if host not in {'127.0.0.1','localhost','::1'} and not (remote and token):
            raise ValueError('remote bind requires GBAI_ALLOW_REMOTE=true and GBAI_API_TOKEN')
        return cls(os.getenv('GBAI_DATA_DIR','./data'),os.getenv('GBAI_DATABASE_PATH','./data/gbai.sqlite3'),os.getenv('GBAI_AUDIT_PATH','./data/audit.sqlite3'),host,port,token,remote)
