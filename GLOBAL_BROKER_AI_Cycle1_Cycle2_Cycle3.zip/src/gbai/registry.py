class ModuleRegistry:
    def __init__(self): self._modules = {}
    def register(self, module):
        name = getattr(module, "name", "")
        if not isinstance(name, str) or not name.strip(): raise ValueError("module needs a non-empty name")
        if name in self._modules: raise ValueError(f"duplicate module: {name}")
        if not callable(getattr(module, "execute", None)): raise TypeError("module needs execute(payload)")
        self._modules[name] = module
    def get(self, name):
        if name not in self._modules: raise KeyError(f"unknown module: {name}")
        return self._modules[name]
    def names(self): return tuple(sorted(self._modules))
