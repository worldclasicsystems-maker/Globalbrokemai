from dataclasses import dataclass
from enum import Enum
from threading import Lock
import time

class HealthState(str, Enum):
    HEALTHY="healthy"
    DEGRADED="degraded"
    QUARANTINED="quarantined"

@dataclass
class ModuleHealth:
    name: str
    state: HealthState = HealthState.HEALTHY
    failures: int = 0
    successes: int = 0
    last_error: str | None = None
    updated_at: float = 0.0

class ModuleHealthManager:
    """Failure threshold-based quarantine; explicit operator reset required."""
    def __init__(self, failure_threshold=3, proof=None):
        if failure_threshold < 1: raise ValueError("threshold must be >= 1")
        self.threshold = failure_threshold
        self.proof = proof
        self._items = {}
        self._lock = Lock()

    def _get(self, name):
        if name not in self._items:
            self._items[name] = ModuleHealth(name=name, updated_at=time.time())
        return self._items[name]

    def success(self, name):
        with self._lock:
            item = self._get(name)
            item.successes += 1
            item.updated_at = time.time()
            if item.state != HealthState.QUARANTINED:
                item.state = HealthState.HEALTHY
            self._record("module.health.success", {"module":name})

    def failure(self, name, error):
        with self._lock:
            item = self._get(name)
            item.failures += 1
            item.last_error = str(error)
            item.updated_at = time.time()
            if item.failures >= self.threshold:
                item.state = HealthState.QUARANTINED
            else:
                item.state = HealthState.DEGRADED
            self._record("module.health.failure", {"module":name,"failures":item.failures,
                                                   "state":item.state.value,"error":str(error)})

    def is_allowed(self, name):
        with self._lock: return self._get(name).state != HealthState.QUARANTINED

    def get(self, name):
        with self._lock:
            item = self._get(name)
            return ModuleHealth(**item.__dict__)

    def reset(self, name):
        with self._lock:
            item = self._get(name)
            item.state=HealthState.HEALTHY; item.failures=0; item.last_error=None
            item.updated_at=time.time()
            self._record("module.health.reset", {"module":name})

    def _record(self, event, payload):
        if self.proof is not None: self.proof.append(event,payload)
