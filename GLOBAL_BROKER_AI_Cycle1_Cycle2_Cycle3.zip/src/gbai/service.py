from pathlib import Path
import json
from .database import JobStore
from .kernel import Kernel
from .builtin import EchoModule
class CoreService:
    def __init__(self,settings):
        Path(settings.data_dir).mkdir(parents=True,exist_ok=True); self.settings=settings
        self.store=JobStore(settings.database_path); self.kernel=Kernel(settings.audit_path); self.kernel.start(); self.kernel.register(EchoModule())
    def health(self):
        ok,msg=self.kernel.proof.verify(); return {'status':'ok' if ok else 'degraded','audit':msg,'kernel_state':self.kernel.state.value}
    def modules(self): return list(self.kernel.registry.names())
    def submit_job(self,module,payload):
        self.kernel.registry.get(module); job=self.store.create(module,payload)
        self.kernel.proof.append('job.queued',{'job_id':job['id'],'module':module}); return job
    def run_job(self,jid):
        job=self.store.get(jid)
        if not job: raise KeyError(jid)
        if job['status']!='queued': raise ValueError('only queued jobs can be run')
        self.store.transition(jid,'running'); outcome=self.kernel.execute(job['module'],json.loads(job['payload_json']))
        if outcome.success:
            result=self.store.transition(jid,'succeeded',result=outcome.result); self.kernel.proof.append('job.succeeded',{'job_id':jid})
        else:
            result=self.store.transition(jid,'failed',error=outcome.error); self.kernel.proof.append('job.failed',{'job_id':jid,'error':outcome.error})
        return result
    def close(self): self.kernel.stop()
