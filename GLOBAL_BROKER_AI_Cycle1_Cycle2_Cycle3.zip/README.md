# GLOBAL BROKER AI — Cycle 1
Local-first modular core foundation. No paid API or cloud service is required.
Includes kernel lifecycle, explicit module registry, FIFO task execution,
isolated task failures, SQLite WAL audit chain, integrity verification, tests and CI.

## Run
Python 3.11+:
```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
pytest
python -m gbai
```
Windows PowerShell activation: `.venv\\Scripts\\Activate.ps1`

## Security boundary
Modules are trusted Python code; this version does not sandbox untrusted plugins.
The local hash chain detects record alteration, but cannot prove authenticity
against an attacker able to rewrite the whole database and recompute hashes.

## Cycle 3: persistent control plane

Adds settings, SQLite job persistence, a local HTTP control API, explicit job lifecycle and audit events. See `docs/CYCLE3.md` and `docs/OPERATIONS.md`. Start after installation with `python -m gbai`; default listener is `127.0.0.1:8787`.
